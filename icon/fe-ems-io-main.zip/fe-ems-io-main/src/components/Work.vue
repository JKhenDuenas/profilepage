<template>
  <div class="progress-journey flex justify-center mt-10 transition-all">
    <ul class="journey-description flex flex-col w-96 text-right">
      <li class="pr-10" data-aos="fade-right" data-aos-duration="500">
        <h2 class="text-sm dark:text-white">Doing Freelancing</h2>
        <span class="text-xs f-gray"> Current</span>
      </li>
      <li></li>
      <li class="pr-10" data-aos="fade-right" data-aos-duration="500">
        <h2 class="text-sm dark:text-white">
          Frontend Developer at Innovations Groups
        </h2>
        <span class="text-xs f-gray"> 02/2022 – 04/2022</span>
      </li>
      <li></li>
      <li class="pr-10" data-aos="fade-right" data-aos-duration="500">
        <h2 class="text-sm dark:text-white">
          Web/Mobile Developer at GOCLOUDASIA
        </h2>
        <span class="text-xs f-gray"> 07/2018 – 06/2019</span>
      </li>
    </ul>
    <ul class="journey flex flex-col w-12 lg:w-5 items-center">
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
    </ul>
    <ul class="journey-description flex flex-col w-96">
      <li></li>
      <li class="pl-10" data-aos="fade-left" data-aos-duration="500">
        <h2 class="text-sm dark:text-white">Frontend Developer at VWALA</h2>
        <span class="text-xs f-gray"> 05/2022 – 08/2022</span>
      </li>
      <li></li>
      <li class="pl-10" data-aos="fade-left" data-aos-duration="500">
        <h2 class="text-sm dark:text-white">
          Software Engineer at Quickstrike Mfg
        </h2>
        <span class="text-xs f-gray"> 06/2019 – 01/2022</span>
      </li>
      <li></li>
    </ul>
  </div>
</template>
