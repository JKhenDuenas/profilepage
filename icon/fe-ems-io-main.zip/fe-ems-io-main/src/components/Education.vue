<template>
  <div class="progress-journey flex justify-center mt-10 transition-all">
    <ul class="journey-description flex flex-col w-96 text-right">
      <li class="pr-10">
        <h2 class="text-sm dark:text-white">
          Bachelor of Science in Information System - La Verdad Christian
          College - Apalit
        </h2>
        <span class="text-xs f-gray"> 2016 – 2018</span>
      </li>
      <li></li>
    </ul>
    <ul class="journey flex flex-col w-12 lg:w-5 items-center">
      <li></li>
      <li></li>
    </ul>
    <ul class="journey-description flex flex-col w-96">
      <li></li>
      <li class="pl-10">
        <h2 class="text-sm dark:text-white">
          Associate in Computer Technology - La Verdad Christian College -
          Apalit
        </h2>
        <span class="text-xs f-gray"> 2014 – 2016</span>
      </li>
    </ul>
  </div>
</template>
