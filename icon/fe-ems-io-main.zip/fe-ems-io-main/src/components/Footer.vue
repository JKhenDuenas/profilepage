<template>
  <div class="bg-gray-900 h-20 flex justify-center items-center">
    <a
      class="text-neutral-500 font-light cursor-pointer dark:text-white"
      href="https://github.com/inspect07/fe-ems-io"
      target="_blank"
    >
      Designed & Built by Emmanuel Santiago
    </a>
  </div>
</template>
